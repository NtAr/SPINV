﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MysteryShip : MonoBehaviour

{
    //private bool isMovingRight = true;
    public float speed = 15;
    public Rigidbody2D rigidBody;

   void FixedUpdate()
    {

        rigidBody = GetComponent<Rigidbody2D>();

        rigidBody.velocity = Vector2.left * speed;
    }

    /*void MoveRight()
    {
        transform.position += Vector3.right * Time.deltaTime * speed;
    }
    void MoveLeft()
    {
        transform.position -= Vector3.left * Time.deltaTime * speed;
    }*/

    /*void ReactRight()
    {
        transform.position = new Vector3(392, 35, 0);
    }

    void ReactLeft()
    {
        transform.position = new Vector3(-401, 35, 0);
    }

    void MoveDown()
    {
        Vector2 position = transform.position;
        position.y -= 0;
        transform.position = position;
    }*/
    void OnCollisionEnter2D(Collision2D col)
    {
        /*if (col.gameObject.name == "LeftWallMS")
        {
            transform.position = Vector2.right * speed;
        }
        if (col.gameObject.name == "RightWallMS")
        {
            transform.position = Vector2.left * speed;
        }*/
        /*if (col.gameObject.name == "RightWallMS")
        {
            MoveDown();
            //GameObject.Find("MysteryShip").SendMessage("ReactRight");
            //transform.position = Vector3.left * speed;
            Vector2 currentDirection = rigidBody.velocity.normalized;
            Vector2 newDirection = (currentDirection + Vector2.left).normalized;
            newDirection = Vector2.Reflect(newDirection, Vector2.left);
            rigidBody.velocity = rigidBody.velocity.magnitude * newDirection;
        }
        if (col.gameObject.name == "LeftWallMS")
        {
            //MoveDown();
            //GameObject.Find("MysteryShip").SendMessage("ReactLeft");
            //transform.position = Vector3.right * speed;
            Vector2 currentDirection = rigidBody.velocity.normalized;
            Vector2 newDirection = (currentDirection + Vector2.right).normalized;
            newDirection = Vector2.Reflect(newDirection, Vector2.right);
            rigidBody.velocity = rigidBody.velocity.magnitude * newDirection;
        }*/
        if (col.gameObject.tag == "Bullet")
        {
            Destroy(gameObject);
        }
    }

    /*void OnCollisionExit2D(Collision2D col)
    {
        if (col.gameObject.name == "LeftWallMS")
        {
            Vector2 currentDirection = rigidBody.velocity.normalized;
            Vector2 newDirection = (currentDirection + Vector2.up).normalized;

            rigidBody.velocity = rigidBody.velocity.magnitude * newDirection;
        }
        if (col.gameObject.name == "RightWallMS")
        {
            Vector2 currentDirection = rigidBody.velocity.normalized;
            Vector2 newDirection = (currentDirection + Vector2.up).normalized;

            rigidBody.velocity = rigidBody.velocity.magnitude * newDirection;
        }
    }*/
}
